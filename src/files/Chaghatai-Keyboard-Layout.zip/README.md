ChaghataiKeyboardLayout
=======================

Chaghatai(an uyghur language using  until the early 20th century) Keyboard Layout for windows 7/8


![image](Keyboard Layouts/keyboard layout images/Chaghata.jpg)

![image](Keyboard Layouts/keyboard layout images/ChaghataShft.jpg)

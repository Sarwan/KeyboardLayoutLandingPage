OldTurkicKeyboardLayout
=======================

Old turkic script(also known as variously Göktürk script, Orkhon script, Orkhon-Yenisey script,uyghur orkhon script) keyboard layout for windows 7/8
